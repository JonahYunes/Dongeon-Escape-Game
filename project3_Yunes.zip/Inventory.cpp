//CSCI1300 Spring 2023 
//Author: Jonah Yunes and Wilder Lockwood
//Recitation: 202 TA: Lin Shi 
//Project 3 - Inventory.cpp

#include "Inventory.h"








using namespace std;




Inventory::Inventory()
{
    //the party starts with 100 gold
    gold = 100;
    ing = 0;


    //party starts with no cookware, weapons, or treasure until they find or buy some
    for (int i = 0; i < 3; i++)
    {
        cookware[i]=0;
    }
    for (int i = 0; i < 5; i++)
    {
        weapons[i]=0;
    }
    armor = 0;
    for (int i = 0; i < 5; i++)
    {
        treasures[i]=0;
    }
   
}


//gold getters and setters
double Inventory::getGold()
{
    return gold;
}
void Inventory::decGold(int gold_u)
{
    gold = gold - gold_u;
}
void Inventory::incGold(int gold_u)
{
    gold += gold_u;
}


//inventory getters and setters
int Inventory::getIng()
{
    return ing;
}
void Inventory::setIng(int ing_u)
{
    ing = ing_u;
}


//cookware getters and setters
int Inventory::getCookwareAt(int id_c)
{
    return cookware[id_c];
}
string Inventory::getcookware_nameeAt(int id_c)
{
    return cookware_name[id_c];
}
void Inventory::setCookwareAt(int num_c, int id_c)
{
    cookware[id_c] = num_c;
}


//weapons getters and setters
int Inventory::getWeaponsAt(int id_w)
{
    return weapons[id_w];
}
string Inventory::getweapon_nameeAt(int id_w)
{
    return weapon_name[id_w];
}
void Inventory::setWeaponsAt(int num_w, int id_w)
{
    weapons[id_w] = num_w;
}


//armor getters and setters
int Inventory::getArmor()
{
    return armor;
}
void Inventory::setArmor(int armor_u)
{
    armor = armor_u;
}


//treasure getters and setters
int Inventory::getTreasuresAt(int id_t)
{
    return treasures[id_t];
}
string Inventory::gettreasure_nameeAt(int id_t)
{
    return treasure_name[id_t];
}
void Inventory::setTreasuresAt(int treasure_u, int id_t)
{
    treasures[id_t] = treasure_u;
}


//party member getter and setter
Member Inventory::getPartyAt(int ind_p)
{
    return Party[ind_p];
}
void Inventory::setPartyAt(Member mem, int ind_p)
{
    Party[ind_p] = mem;
}






//the inventory display
void Inventory::display()
{
    cout << "+-------------+"<< endl;
    cout << "| INVENTORY   |"<< endl;
    cout << "+-------------+"<< endl;
    cout << "| Gold        | " << gold << endl;
    cout << "| Ingredients | " << ing << " kg" << endl;
    cout << "| Cookware    | " << "P: " << cookware[0] << " | F: " << cookware[1] << " | C: " << cookware[2] << endl;
    cout << "| Weapons     | " << "C: " << weapons[0] << " | S: " << weapons[1] << " | R: " << weapons[2] << "| B: " << weapons[3] << "| L: " << weapons[4] << endl;
    cout << "| Armor       | " << armor << endl;
    cout << "| Treasures   | " << "R: " << treasures[0] << " | N: " << treasures[1] << " | B: " << treasures[2] << "| C: " << treasures[3] << "| G: " << treasures[4] << endl;
}



