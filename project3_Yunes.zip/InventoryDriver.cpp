//CSCI1300 Spring 2023 
//Author: Jonah Yunes and Wilder Lockwood
//Recitation: 202 TA: Lin Shi 
//Project 3 - InventoryDriver.cpp

#include "Inventory.h"








using namespace std;




int main(){


    Inventory inv;


    inv.getGold();// equals 100


    inv.decGold(10);
    inv.getGold();// equals 90


    inv.incGold(20);
    inv.getGold();//equals 110


    inv.setArmor(3);
    inv.getArmor(); // equals 3


    inv.setCookwareAt(3,1);
    inv.getCookwareAt(1); // equals 3


    inv.setIng(25);
    inv.getIng(); // equals 25


    Member memb;
    inv.setPartyAt(memb, 0);
    Member getMemb = inv.getPartyAt(0);


    getMemb.displayMember(); // no name with 50 hunger


    inv.setTreasuresAt(1, 2);
    inv.getTreasuresAt(2); // equals 1


    inv.setWeaponsAt(3, 4);
    inv.getWeaponsAt(4); // equals 3
}