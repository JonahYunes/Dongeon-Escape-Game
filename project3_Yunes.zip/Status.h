//CSCI1300 Spring 2023 
//Author: Jonah Yunes and Wilder Lockwood
//Recitation: 202 TA: Lin Shi 
//Project 3 - Status.h


#ifndef Stat_H
#define Stat_H

#include <iostream>
#include "Inventory.h"

using namespace std;

class Status
{
    private:
    int rooms_cleared;
    int keys;
    int anger;

    public:
    Status();

    int getRooms_cleared();
    void gainRooms_cleared();
    // return keys
    int getKeys();
    // add one key to keys
    void gainKeys();
    // decrease amount of keys if there is more than 0
    void useKeys();
    // return the anger level
    int getAnger();
    // inreases the anger
    void setAnger(int anger_u);
    // display
    void displayStatus(Inventory inv);
    void askNames();

};
#endif