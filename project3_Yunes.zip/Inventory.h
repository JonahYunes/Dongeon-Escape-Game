//CSCI1300 Spring 2023 
//Author: Jonah Yunes and Wilder Lockwood
//Recitation: 202 TA: Lin Shi 
//Project 3 - Inventory.h


#ifndef Inven_H
#define Inven_H




#include <iostream>
#include <vector>
#include <iomanip>
#include "Member.h"




using namespace std;




class Inventory
{
    private:
    //private variables keeping track of everything the player has
    double gold;
    int ing; // kg
    static const int cook= 3;
    int cookware[cook];
    int weapons[5];
    int armor;
    int treasures[5];


    // arrays of names for the different cookware, weapons, and treasure
    string cookware_name[3] {"ceramic pot (P)", "frying pan (F)", "cauldron (C)"};
    string weapon_name[5] {"club (C)", "spear (S)", "+1 rapier (R) ", "+2 battle-axe (B)", "+3 longsword (L)"};
    string treasure_name[5] {"Silver ring (R)", "Ruby necklace (N)", "Emerald bracelet (B)", "Diamond circlet (C)", "Gem-encrusted goblet (G)"};


    //our example of an array of class objects, we use member for our party of five
    Member Party[5];








    public:
    //unparameterized constructor, only used once
    Inventory();


    //getter and setters for gold
    double getGold();
    void decGold(int gold_u);
    void incGold(int gold_u); // inc and dec have different setters


    //getter and setter for ing
    int getIng();
    void setIng(int ing_u);


    //getter and setter for the cookware array
    int getCookwareAt(int id_c);
    string getcookware_nameeAt(int id_c); //works for the cookware names
    void setCookwareAt(int num_c, int id_c);


    //getter and setter for the weapons array
    int getWeaponsAt(int id_w);
    string getweapon_nameeAt(int id_w); // works for the weapons names
    void setWeaponsAt(int num_w, int id_w);


    //getter and setter for armor
    int getArmor();
    void setArmor(int armor_u);


    //getter and setter for treasure array
    int getTreasuresAt(int id_t);
    string gettreasure_nameeAt(int id_t); // works for the treasure names
    void setTreasuresAt(int treasure_u, int id_t);


    //outputs everything in the players inventory
    void display();


    //getter and setter for the array of party members
    Member getPartyAt(int ind_p);
    void setPartyAt(Member mem, int ind_p);




};
#endif
