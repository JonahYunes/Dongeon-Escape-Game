//CSCI1300 Spring 2023 
//Author: Jonah Yunes and Wilder Lockwood
//Recitation: 202 TA: Lin Shi 
//Project 3 - Merchant.h


#ifndef Merch_H
#define Merch_H

#include <iostream>
#include "Inventory.h"
using namespace std;


class Merchant{
    private:
    // prices for everything in the store
        double ingredientP;
        double weaponsP[5];
        double armorP;
        double cookwareP[3];
        int treasureP[5];




    public:
        //merchant constructor
        Merchant();

        double getingredientP();


        //prints out merchant shop and allows player to buy items
        Inventory shopM(Inventory inv);


        //increases all prices by 25%
        void increasePrices();


        //provides a riddle for player before accessing NPC, returns true or false
        bool solveRiddle();

        // getters for private data members
        double getIngredientP();
        double getWeaponsPAt(int ind_w);
        double getArmorP();
        double getCookwarePAt(int ind_c);
        int getTreasurePAt(int ind_t);
        // split function
        int split(string inputString, char separator, string arr[], int size);


};
#endif