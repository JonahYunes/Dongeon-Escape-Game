//CSCI1300 Spring 2023 
//Author: Jonah Yunes and Wilder Lockwood
//Recitation: 202 TA: Lin Shi 
//Project 3 - Merchant.cpp


#include <iostream>
#include <fstream>
#include "Merchant.h"
#include "Status.h"
#include "Inventory.h"


using namespace std;



Merchant::Merchant()
{
    ingredientP = 1;

    // fixed values of weapon prices
    weaponsP[0] = 2;
    weaponsP[1] = 2;
    weaponsP[2] = 5;
    weaponsP[3] = 15;
    weaponsP[4] = 50;

    // fixed armor prices
    armorP = 5;

    // cookware prices
    cookwareP[0] = 2;
    cookwareP[1] = 10;
    cookwareP[2] = 20;

    // treasure prices
    treasureP[0] = 10;
    treasureP[1] = 20;
    treasureP[2] = 30;
    treasureP[3] = 40;
    treasureP[4] = 50;
}


Inventory Merchant::shopM(Inventory inv)
{
    cout << "If you're looking to get supplies, you've come to the right place." << endl;
    cout << "I would be happy to part with some of my wares...for the proper price!" << endl;
    cout << endl;
    int opt = 1;
    while(opt == 1 || opt == 2 || opt == 3 || opt == 4 || opt == 5 || opt == 6)
    {
        // printing out the menue
        cout << endl;
        inv.display();
        cout << endl;
        cout << "Choose one of the following:" << endl;
        cout << " 1. Ingredients: To make food, you have to cook raw ingredients." << endl;
        cout << " 2. Cookware: You will need something to cook those ingredients." << endl;
        cout << " 3. Weapons: It's dangerous to go alone, take this!" << endl;
        cout << " 4. Armor: If you want to survive monster attacks, you will need some armor." << endl;
        cout << " 5. Sell treasures: If you find anything shiny, I would be happy to take it off your hands." << endl;
        cout << " 6. Leave: Make sure you get everything you need, I'm leaving after this sale!" << endl << endl;
        cin >> opt;
        // making sure that they put in the right input
        while ((opt > 6) || (0 >= opt))
        {
            cout << endl;
            inv.display();
            cout << endl;
            cout << "Invalid input." << endl;
            cout << "Choose one of the following:" << endl;
            cout << " 1. Ingredients: To make food, you have to cook raw ingredients." << endl;
            cout << " 2. Cookware: You will need something to cook those ingredients." << endl;
            cout << " 3. Weapons: It's dangerous to go alone, take this!" << endl;
            cout << " 4. Armor: If you want to survive monster attacks, you will need some armor." << endl;
            cout << " 5. Sell treasures: If you find anything shiny, I would be happy to take it off your hands." << endl;
            cout << " 6. Leave: Make sure you get everything you need, I'm leaving after this sale!" << endl;
            cin >> opt;
        }

        if (opt == 1)
        {
            // asking how many ingredients they would like
            int num_ing = 0;
            cout << "How many kg of ingredients do you need [1 Gold/kg]? "
                << "(Enter a positive mulitple of 5, or 0 to cancel)" << endl;
                cin >> num_ing;
            // making the input is a multiple of five
            while(num_ing % 5 != 0)
            {
                cout << "not a multiple of 5" << endl;
                cout << "How many kg of ingredients do you need [1 Gold/kg]? "
                << "(Enter a positive mulitple of 5, or 0 to cancel)" << endl;
                cin >> num_ing;
            }
            // making sure they have the money to pay for the ingredients
            while (inv.getGold() < num_ing)
            {
                cout << "You don't have enough gold!" << endl;
                cout << "How many kg of ingredients do you need [1 Gold/kg]? "
                << "(Enter a positive mulitple of 5, or 0 to cancel)" << endl;
                cin >> num_ing;
            }
            // going back to the main menue if they pick zero
            if (num_ing == 0)
            {
                inv.setIng(num_ing);
                inv.decGold(num_ing*ingredientP);
                cout << endl;
                cout << "Thank you for your patronage! What else can I get for you?" << endl;
                cout << endl;
            }
            else if (num_ing <= inv.getGold())
            {
                // asking and confirming the transaction
                char y_n;
                cout << "You want to buy " << num_ing << " kg of ingredients for " << (num_ing*ingredientP) << " Gold? (y/n)" << endl;
                cin >> y_n;
                
                // making sure they have the money
                while ((num_ing*ingredientP) > inv.getGold())
                {
                    cout << "You don't have enough gold!" << endl;
                    cout << "How many would you like? (Enter a positive integer, or 0 to cancel)" << endl;
                    cin >> num_ing;
                    if (num_ing == 0)
                    {
                        inv.setIng(num_ing);
                        inv.decGold(num_ing*ingredientP);
                        cout << endl;
                        cout << "Thank you for your patronage! What else can I get for you?" << endl;
                        cout << endl;
                        break;
                    }
                }
                // if they say yes then the gold is decreased and the inventory updates
                if (y_n == 'y')
                {
                    inv.setIng(num_ing);
                    inv.decGold(num_ing*ingredientP);
                    cout << endl;
                    cout << "Thank you for your patronage! What else can I get for you?" << endl;
                    cout << endl;
                }
                else
                {
                    cout << endl;
                    cout << "Thank you for your patronage! What else can I get for you?" << endl;
                    cout << endl;
                }
            }
        }

        if (opt == 2)
        {
            // asking for which cookware they want
            int cook_t = 0;
            cout << "I have a several types of cookware, which one would you like?" << endl;
            cout << "Each type has a different probability of breaking when used, marked with (XX%)." << endl;
            cout << endl;
            cout << "Choose one of the following:" << endl;
            cout << " 1. (25%) Ceramic Pot [2 Gold]" << endl;
            cout << " 2. (10%) Frying Pan [10 Gold]" << endl;
            cout << " 3. ( 2%) Cauldron [20 Gold]" << endl;
            cout << " 4. Cancel" << endl;
            cin >> cook_t;
            // making sure they put the right number and type of cookware
            while (cook_t > 4 || 0 >= cook_t)
            {
                cout << "Invalid input." << endl;
                cout << "Choose one of the following:" << endl;
                cout << " 1. (25%) Ceramic Pot [2 Gold]" << endl;
                cout << " 2. (10%) Frying Pan [10 Gold]" << endl;
                cout << " 3. ( 2%) Cauldron [20 Gold]" << endl;
                cout << " 4. Cancel" << endl;
                cin >> cook_t;
            }
            // if they want to leave then this leads back to the main menue
            if (cook_t == 4)
            {
                cout << endl;
                cout << "Thank you for your patronage! What else can I get for you?" << endl;
                cout << endl;

            }

            // how many of this type would you like
            // and take in that number
            int num_c = 0;
            cout << "How many would you like? (Enter a positive integer, or 0 to cancel)" << endl;
            cin >> num_c;

            if (num_c == 0)
            {
                cout << endl;
                cout << "Thank you for your patronage! What else can I get for you?" << endl;
                cout << endl;
            }
            else
            {
                // making sure they put the right number
                while (num_c < 0)
                {
                    cout << "Invalid input" << endl;
                    cout << "How many would you like? (Enter a positive integer, or 0 to cancel)" << endl;
                    cin >> num_c;
                }
                // amking sure they have the money
                while ((num_c * cookwareP[cook_t-1]) > inv.getGold())
                {
                    cout << "You don't have enough gold!" << endl;
                    cout << "How many would you like? (Enter a positive integer, or 0 to cancel)" << endl;
                    cin >> num_c;
                }
                // confirming the transaction
                char yn;
                cout << "You want to buy " << num_c << " " << inv.getcookware_nameeAt(cook_t-1) << " for " << (num_c * cookwareP[cook_t-1]) << " Gold? (y/n)" << endl;
                cin >> yn;

                // if they pick yes then update the inventory and return to main menue
                // if they pick no then nothing happens and return to main menue
                if (yn == 'y')
                {
                    inv.setCookwareAt(num_c,cook_t-1);
                    inv.decGold(num_c * cookwareP[cook_t-1]);
                    cout << endl;
                    cout << "Thank you for your patronage! What else can I get for you?" << endl;
                    cout << endl;
                
                }
                else
                {
                    cout << endl;
                    cout << "Thank you for your patronage! What else can I get for you?" << endl;
                    cout << endl;
                }
            }
        }


        if (opt == 3)
        {
            // taking input for the type of weapon
            int weapon_t = 0;
            cout << "I have a plentiful collection of weapons to choose from, what would you like?" << endl;
            cout << "Note that some of them provide you a special bonus in combat, marked by a (+X)." << endl;
            cout << endl;
            cout << "Choose one of the following:" << endl;
            cout << " 1. Stone Club [2 Gold]" << endl;
            cout << " 2. Iron Spear [2 Gold]" << endl;
            cout << " 3. (+1) Mythril Rapier [5 Gold]" << endl;
            cout << " 4. (+2) Flaming Battle-Axe [15 Gold]" << endl;
            cout << " 5. (+3) Vorpal Longsword [50 Gold]" << endl;
            cout << " 6. Cancel" << endl;
            cin >> weapon_t;

            // checking to take in the the right input 
            while (weapon_t > 6 || 0 >= weapon_t)
            {
                cout << "Invalid input." << endl;
                cout << "Choose one of the following:" << endl;
                cout << " 1. Stone Club [2 Gold]" << endl;
                cout << " 2. Iron Spear [2 Gold]" << endl;
                cout << " 3. (+1) Mythril Rapier [5 Gold]" << endl;
                cout << " 4. (+2) Flaming Battle-Axe [15 Gold]" << endl;
                cout << " 5. (+3) Vorpal Longsword [50 Gold]" << endl;
                cout << " 6. Cancel" << endl;
                cin >> weapon_t;
            }
            

            // return to the the main menue if they pick 6
            if (weapon_t == 6)
            {
                cout << endl;
                cout << "Thank you for your patronage! What else can I get for you?" << endl;
                cout << endl;
            }
            else
            {
                // ask how many they want
                int num_w = 0;
                cout << "How many would you like? (Enter a positive integer, or 0 to cancel)" << endl;
                cin >> num_w;
                if (num_w > 5)
                {
                    cout << "can't buy that many weapons" << endl;
                }
                // counting how many they have already
                int numweapons = 0;
                for (int i = 0; i < 5; i++)
                {
                    numweapons += inv.getWeaponsAt(i);
                }

                // if they pick zero then return to the main menue
                if (num_w == 0)
                {
                    cout << endl;
                    cout << "Thank you for your patronage! What else can I get for you?" << endl;
                    cout << endl;
                }
                else
                {
                    // making sure to take in the right input
                    while (num_w < 0)
                    {
                        cout << "Invalid input" << endl;
                        cout << "How many would you like? (Enter a positive integer, or 0 to cancel)" << endl;
                        cin >> num_w;
                    }
                    // making sure they have enough money for the transaction
                    while ((num_w * weaponsP[weapon_t-1]) > inv.getGold())
                    {
                        cout << "You don't have enough gold!" << endl;
                        cout << "How many would you like? (Enter a positive integer, or 0 to cancel)" << endl;
                        cin >> num_w;
                    }

                    // making sure they can buy this amount of weapons
                    if (!((numweapons + num_w) > 5))
                    {
                        // confirmation for the transaction
                        char yn;
                        cout << "You want to buy " << num_w << " " << inv.getweapon_nameeAt(weapon_t-1) << " for " << (num_w * weaponsP[weapon_t-1]) << " Gold? (y/n)" << endl;
                        cin >> yn;
                        // if they pick yes then update the inventory
                        if (yn == 'y')
                        {
                            inv.setWeaponsAt(num_w, weapon_t-1);
                            inv.decGold(num_w * weaponsP[weapon_t-1]);
                            cout << endl;
                            cout << "Thank you for your patronage! What else can I get for you?" << endl;
                            cout << endl;
                        }
                        else
                        {
                            // return to main menue
                            cout << endl;
                            cout << "Thank you for your patronage! What else can I get for you?" << endl;
                            cout << endl;
                        }
                    }
                    else
                    {
                        // returning to main menue since they have too many weapons
                        cout << "You have too many weapons already!" << endl;
                    }
                } 
            }
        }

        if (opt == 4)
        {
            // checking for how many peices of armor they want
            int num_armor = 0;
            cout << "How many suits of armor can I get you? "
                << "(Enter a positive integer, or 0 to cancel)" << endl;
                cin >> num_armor;

            // returning to main menue if they pick zero
            if (num_armor == 0)
            {
                cout << endl;
                cout << "Thank you for your patronage! What else can I get for you?" << endl;
                cout << endl;
            }
            else
            {
                // making sure they have gold
                if (num_armor <= inv.getGold())
                {
                    // confirming the transacion for armor
                    char y_n;
                    cout << "You want to buy " << num_armor << " suit(s) of armor for " << (num_armor*armorP) << " Gold? (y/n)" << endl;
                    cin >> y_n;
                    // making sure they have the gold to buy it
                    while ((num_armor*armorP) > inv.getGold())
                    {
                        cout << "You don't have enough gold!" << endl;
                        cout << "How many would you like? (Enter a positive integer, or 0 to cancel)" << endl;
                        cin >> num_armor;
                    }
                    // cancling and returning to main menue
                    if (num_armor == 0)
                    {
                        inv.setIng(inv.getArmor() + num_armor);
                        inv.decGold(num_armor*armorP);
                        cout << endl;
                        cout << "Thank you for your patronage! What else can I get for you?" << endl;
                        cout << endl;
                    }
                    else
                    {
                        // if they pick yes then update menue and return to main menue
                        if (y_n == 'y')
                        {
                            inv.setArmor(num_armor);
                            inv.decGold(num_armor*armorP);
                            cout << endl;
                            cout << "Done!" << endl;
                            cout << endl;
                            cout << "Thank you for your patronage! What else can I get for you?" << endl;
                            cout << endl;
                        }
                        else
                        {
                            // returning to main menue
                            cout << endl;
                            cout << "Thank you for your patronage! What else can I get for you?" << endl;
                            cout << endl;
                        }
                    }
                }
            }
            
        }

        if (opt == 5)
        {
            // asking if they want to sell all of their treasure 
            char z;
            cout << "Would you like to like to sell all of your treasue? (y/n)" << endl;
            cin >> z;
            // if yes then update inventory
            // if no then return to main menue
            if (z == 'y')
            {
                inv.incGold(inv.getTreasuresAt(0)*treasureP[0]);
                inv.setTreasuresAt(0, 0);
                inv.incGold(inv.getTreasuresAt(1)*treasureP[1]);
                inv.setTreasuresAt(0, 1);
                inv.incGold(inv.getTreasuresAt(2)*treasureP[2]);
                inv.setTreasuresAt(0, 2);
                inv.incGold(inv.getTreasuresAt(3)*treasureP[3]);
                inv.setTreasuresAt(0, 3);
                inv.incGold(inv.getTreasuresAt(4)*treasureP[4]);
                inv.setTreasuresAt(0, 4);
                cout << endl;
                cout << "Shiny!" << endl;
                cout << endl;
                cout << "Thank you for your patronage! What else can I get for you?" << endl;
                cout << endl;
            }
            else
            {
                cout << endl;
                cout << "Thank you for your patronage! What else can I get for you?" << endl;
                cout << endl;
            }

        }

        if (opt == 6)
        {
            // confirming exit
            char x;
            cout << "Are you sure you're finished? You won't be able to buy anything else from me! (y/n)" << endl;
            cin >> x;

            // if yes then exit 
            // if no then return to main menue
            if (x == 'y')
            {
                cout << "Stay safe out there! Goodbye!" << endl;
                return inv;
            }
            else
            {
                continue;
            }
        }
    }
}


void Merchant::increasePrices()
{
    // increasing all prices by 25%
    // ging through all price arrays and increasing the prices
    ingredientP += ingredientP*(.25);
    armorP += armorP*(.25);
    for (int i = 0; i < 3; i++)
    {
        cookwareP[i] += (cookwareP[i]*.25);
    }
    for (int j = 0; j < 5; j++)
    {
        weaponsP[j] += (weaponsP[j]*.25);
    }
    for (int l = 0; l < 5; l++)
    {
        treasureP[l] += (treasureP[l]*.25);
    }
}



double Merchant::getIngredientP()
{
    // return the ingredients price
    return ingredientP;
}
double Merchant::getWeaponsPAt(int ind_w)
{
    // returning the weapons price at the spef index
    return weaponsP[ind_w];
}
double Merchant::getArmorP()
{
    // return the armor price
    return armorP;
}
double Merchant::getCookwarePAt(int ind_c)
{
    // returning cookware price at spef index
    return cookwareP[ind_c];
}
int Merchant::getTreasurePAt(int ind_t)
{
    // returning treasure price at a spef index
    return treasureP[ind_t];
}


int Merchant::split(string input_string, char separator, string arr[], int arr_size){
    int num_splits = 0;
    int ch=0;
    string eb = "";
    for (int i = 0; i < input_string.length(); i++)
    {
        if (num_splits >= arr_size)
        {
            return -1;
        }
        if (input_string[i] != separator)
        {
            // adding all charecters before reaching seperator in an empty string
            eb = eb+input_string[i];
            
        }
        else
        {
            // adding num_splits and storing atring eb in arr
            arr[num_splits] = eb;
            num_splits++;
            // resetting eb
            eb = "";
        }
    }
    arr[num_splits] = eb;
    num_splits++;
    eb = "";
    // making sure to return the right value for num splits
    if (0 == arr_size)
    {
        return 0;
    }
    if (input_string == "")
    {
        return 0;
    }
    return num_splits;
}



bool Merchant::solveRiddle(){
	bool correct = false;
    while(correct == false){
        string line;
        vector<string> lines;
        srand(time(0));


        ifstream file("riddles.txt");


        while(getline(file,line)){
            lines.push_back(line);  
        }
        //random line number
        int random_number= (rand() % 20);


        string choice;


        string arr[2];


        //splits line into question and answers
        split(lines[random_number], '~', arr, 2);
        //splits answers into four options
        cout << "You really wanna trade with me? Amusing, solve my riddle first." << endl;
        cout << arr[0] << endl;
       
        cin >> choice;
        if(choice == arr[1]){
            correct = true;
           
        }else{
            correct = false;
        }
    }
}

