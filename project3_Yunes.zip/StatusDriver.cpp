//CSCI1300 Spring 2023 
//Author: Jonah Yunes and Wilder Lockwood
//Recitation: 202 TA: Lin Shi 
//Project 3 - StatusDriver.cpp


#include <iostream>
#include "Status.h"
#include "Inventory.h"
#include <cassert>
using namespace std;
int main()
{
    Status stat;
    assert(stat.getAnger() == 0);
    assert(stat.getKeys() == 0);
    assert(stat.getRooms_cleared() == 0);

    stat.gainKeys();
    assert(stat.getKeys() == 1);

    stat.useKeys();
    assert(stat.getKeys() == 0);

    stat.setAnger(5);
    assert(stat.getAnger() == 5);
    Inventory inv;
    stat.displayStatus(inv);
    // ecpectinng:
    /*cout << "+-------------+" << endl;
    cout << "|   Status    |" << endl;
    cout << "+-------------+" << endl;// idk what to do here
    cout << "| Rooms Cleared: " << rooms_cleared << " | " << "Keys: " << keys << " | " << "Anger Level: " << anger <<endl;
    inv.display();
    cout << "+-------------+" << endl;
    cout << "| PARTY       |" << endl;
    cout << "+-------------+" << endl;
    for (int i = 0; i < 5; i++)
    {
        inv.getPartyAt(i).displayMember();
    }
    cout << "+-------------+" << endl;
    */
    return 0;
}
