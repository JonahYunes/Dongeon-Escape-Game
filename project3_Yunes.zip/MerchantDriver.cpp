//CSCI1300 Spring 2023 
//Author: Jonah Yunes and Wilder Lockwood
//Recitation: 202 TA: Lin Shi 
//Project 3 - MerchantDriver.cpp


#include <iostream>
#include <fstream>
#include <cassert>
#include "Merchant.h"
#include "Status.h"
#include "Inventory.h"


using namespace std;

int main()
{
    Merchant merch;

    // testing ingrefient price
    assert(merch.getingredientP() == 1);
    
    // testing armor price
    assert(merch.getArmorP() == 5);

    // testing weapons prices
    assert(merch.getWeaponsPAt(0) == 2);
    assert(merch.getWeaponsPAt(1) == 2);
    assert(merch.getWeaponsPAt(2) == 5);
    assert(merch.getWeaponsPAt(3) == 15);
    assert(merch.getWeaponsPAt(4) == 50);

    // testing cookware prices
    assert(merch.getCookwarePAt(0) == 2);
    assert(merch.getCookwarePAt(1) == 10);
    assert(merch.getCookwarePAt(2) == 20);

    // treasure prices
    assert(merch.getTreasurePAt(0) == 10);
    assert(merch.getTreasurePAt(1) == 20);
    assert(merch.getTreasurePAt(2) == 30);
    assert(merch.getTreasurePAt(3) == 40);
    assert(merch.getTreasurePAt(4) == 50);





}
