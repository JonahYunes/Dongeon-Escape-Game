//CSCI1300 Spring 2023 
//Author: Jonah Yunes and Wilder Lockwood
//Recitation: 202 TA: Lin Shi 
//Project 3 - Member.cpp


#ifndef Mem_H
#define Mem_H




#include <iostream>
using namespace std;








class Member{
    private:
    //private variables for each party member individually, including their name and hunger
        //also a boolean for whether the member is alive or not
        string name;
        int hunger;
        bool alive;
















    public:
        Member();
        //parameterized constructor
        Member(string new_name);








        //returns member name
        string getName();


    //returns hunger of member
        int getHunger();








        //decreases member hunger by num
        void decHunger(int num);








        //increases member hunger by num
        void incHunger(int num);








        //returns is member is alive
        bool isAlive();








        //kills member, bool equals false
        void killMember();








        //displays a member name and hunger if they are alive
        void displayMember();








};
#endif

