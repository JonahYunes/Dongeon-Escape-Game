//CSCI1300 Spring 2023 
//Author: Jonah Yunes and Wilder Lockwood
//Recitation: 202 TA: Lin Shi 
//Project 3 - Status.cpp


#include <iostream>
#include "Status.h"


using namespace std;

Status::Status()
{
    // defaul costructor sets everything to zero
    rooms_cleared = 0;
    keys = 0;
    anger = 0;
}
int Status::getRooms_cleared()
{
    // returns rooms cleared
    return rooms_cleared;
}
void Status::gainRooms_cleared()
{
    // increases the amount of rooms they cleared
    rooms_cleared++;
}
int Status::getKeys()
{
    // return the amount of keys they have
    return keys;
}
void Status::gainKeys()
{
    // increase the keys by one
    keys++;
}
void Status::useKeys()
{
    // decrease the keys by one
    keys--;
}
int Status::getAnger()
{
    // return the anger
    return anger;
}
void Status::setAnger(int anger_u)
{
    // inrease the anger
    anger = anger_u;
}
void Status::displayStatus(Inventory inv)
{
    // displays the status, inventory, and members
    cout << "+-------------+" << endl;
    cout << "|   Status    |" << endl;
    cout << "+-------------+" << endl;// idk what to do here
    cout << "| Rooms Cleared: " << rooms_cleared << " | " << "Keys: " << keys << " | " << "Anger Level: " << anger <<endl;
    inv.display();
    cout << "+-------------+" << endl;
    cout << "| PARTY       |" << endl;
    cout << "+-------------+" << endl;
    for (int i = 0; i < 5; i++)
    {
        inv.getPartyAt(i).displayMember();
    }
    cout << "+-------------+" << endl;

}