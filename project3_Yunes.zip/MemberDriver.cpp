//CSCI1300 Spring 2023 
//Author: Jonah Yunes and Wilder Lockwood
//Recitation: 202 TA: Lin Shi 
//Project 3 - Member.h

#include <iostream>
using namespace std;
#include "Member.h"





int main(){
    string name = "Joe";


    Member emptyM;
    Member paraM(name);


    emptyM.getName(); // equals ""


    paraM.getName(); // equals Joe


    emptyM.getHunger(); // equals 50
    emptyM.decHunger(10);
    emptyM.getHunger(); // equals 40




    paraM.getHunger(); // equals 50
    paraM.incHunger(10);
    paraM.getHunger(); // equals 60


    emptyM.killMember();
    if(!emptyM.isAlive()){
        cout << "dead" << endl; //correct
    }


    if(paraM.isAlive()){
        cout << "alive" << endl; //correct
    }


    emptyM.displayMember(); //40 hunger, no name, dead
    paraM.displayMember(); //60 hunger, Joe, alive
}