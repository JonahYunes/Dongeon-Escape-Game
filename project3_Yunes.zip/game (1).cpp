//CSCI1300 Spring 2023 
//Author: Jonah Yunes and Wilder Lockwood 
//Recitation: 202 TA: Lin Shi 
//Project 3 - game.cpp (The actual game)

#include <iostream>
#include <fstream>
#include "Map.h"
#include "Inventory.h"
#include "Merchant.h"
#include "Status.h"
#include "Member.h"




using namespace std;



//our sorting algorith which sorts out party members from highest to lowest based on hunger
Inventory sortTeammatesHunger(Inventory inv){
    Member memb[4] {inv.getPartyAt(1),inv.getPartyAt(2),inv.getPartyAt(3),inv.getPartyAt(4)};
    Member returnMemb[4];
    string allnames[4];
    Member maxMemb;
    string max_m;
    int size = 4, pos, max;
    int array[size];
    int array2[size];






    //creates temp array
   for (int i = 0; i < size; i++)
   {
        array[i] = memb[i].getHunger();
   }






    //double for loop
   for (int i = 0; i < size; i++)
   {








        max = 0;
        pos = 0;
        for (int q = 0; q < size; q++)
        {
            if (array[q] > max)
            {
                //puts highest hunger at first avliable position in output array
                max = array[q];
                max_m = memb[q].getName();
                pos = q;
            }
        }
        array2[i] = max;
        allnames[i] = max_m;
        array[pos] = 0;
   }


    //use orders hunger and names to add old members to new returned member array
    for (int i = 0; i < 4; i++)
    {
        for (int j=0; j<4; j++){
            if (allnames[i] == memb[j].getName()){
                returnMemb[i] = memb[j];
            }
        }
    }




    inv.setPartyAt(returnMemb[0], 1);
    inv.setPartyAt(returnMemb[1], 2);
    inv.setPartyAt(returnMemb[2], 3);
    inv.setPartyAt(returnMemb[3], 4);








    return inv;
}



//a misfortune has a chance of many different bad things happening to the party
Inventory misfortune(Inventory inv){  
    Member memb[5] {inv.getPartyAt(0),inv.getPartyAt(1),inv.getPartyAt(2),inv.getPartyAt(3),inv.getPartyAt(4)};
    srand(time(0));
    int start_number= (rand() % 10);
    //40% chance of misfortune occuring
    if(start_number < 4){
        int event_number = (rand() % 10);
        //this misfortune results in lost items
        if(event_number < 3){
            int spef_number = (rand() % 3);
            //lost food
            if(spef_number == 0){
                //dec ing
                cout << "Oh no! A thieving goblin stole some of your food while your back was turned." << endl;
                if(inv.getIng() > 10){
                    inv.setIng(inv.getIng() - 10);
                }
                else{
                    inv.setIng(0);
                }
            }
            //lost cooking equipment
            else if(spef_number == 1){
                int i = 0;
                bool cond = false;
                while(cond == false && i < 3){
                    if(inv.getCookwareAt(i) != 0){
                        cout << "Oh no! A nasty looking chef took your cooking equipment." << endl;
                        inv.setCookwareAt(inv.getCookwareAt(i) - 1,i);
                        cond = true;
                    }
                    else{
                        i++;
                    }
                }
                if (cond == false){
                    cout << "You got lucky. A nasty chef went for your cooking bag but it's empty." << endl;
                }
            }
            //lost armor
            else{
                if (inv.getArmor() != 0){
                    inv.setArmor(inv.getArmor() - 1);
                    cout << "That was close! A phantom just ripped the armor right off your body." << endl;
                }
                else{
                    cout << "A phantom swooped right by your head. That was close!" << endl;
                }
            }
        }
        //this misfortune result in lost battle equipment
        else if(event_number < 4){
            int spef_number = (rand() % 2);
            //lose armor
            if(spef_number == 0){
                if (inv.getArmor() != 0){
                    inv.setArmor(inv.getArmor() - 1);
                    cout << "That was close! A phantom just ripped the armor right off your body. Good thing it wasn't your arm." << endl;
                }
                else{
                    cout << "A phantom swooped right by your head. That was close!" << endl;
                }
            }
            //lose weapon
            else if(spef_number == 1){
                int i = 0;
                bool cond = false;
                while(cond == false && i < 5){
                    if(inv.getWeaponsAt(i) != 0){
                        cout << " Oh no! A big ugly slime man took one of your weapons." << endl;
                        inv.setWeaponsAt(inv.getWeaponsAt(i) - 1,i);
                        cond = true;
                    }
                    else{
                        i++;
                    }
                }
                if (cond == false){
                    cout << "You got lucky. A big slime man went for ur weapons bag but it was empty." << endl;
                }
            }
        }
        //this misfortune gives a randome party member a parasite
        else if(event_number < 7){
            bool cond = false;
            while(cond == false){
                int spef_number = (rand() % 4) + 1;
                if(memb[spef_number].isAlive() == true){
                    cond = true;
                    cout << "Oh no! One of your party members got a dungeon stomach parasite." << endl;
                    //parasite kills member
                    if(memb[spef_number].getHunger() < 11){
                        memb[spef_number].killMember();
                        cout << memb[spef_number].getName() <<" died from the parasite." << endl;
                    }
                    //member loses 10 hunger point
                    else{
                        memb[spef_number].decHunger(10);
                        cout << "The party member " << memb[spef_number].getName() << " lost 10 hunger points." << endl;
                    }
                }
            }
        }
        else{
            //not a room
        }
        inv.setPartyAt(memb[0], 0);
        inv.setPartyAt(memb[1], 1);
        inv.setPartyAt(memb[2], 2);
        inv.setPartyAt(memb[3], 3);
        inv.setPartyAt(memb[4], 4);
    }
    else{
        //no misfortune
    }








    return inv;
}




//this misfortune is the same as the previous misfortune except a few key changes
Inventory room_misfortune(Inventory inv){
    Member memb[5] {inv.getPartyAt(0),inv.getPartyAt(1),inv.getPartyAt(2),inv.getPartyAt(3),inv.getPartyAt(4)};
    srand(time(0));
    int start_number= (rand() % 10);
    //misfortune has a 60% chance of occuring
    if(start_number < 6){
        int event_number = (rand() % 10);
        if(event_number < 3){
            int spef_number = (rand() % 3);
            if(spef_number == 0){
                //dec ing
                cout << "Oh no! A thieving goblin stole some of your food while your back was turned." << endl;
                if(inv.getIng() > 10){
                    inv.setIng(inv.getIng() - 10);
                }
                else{
                    inv.setIng(0);
                }
            }
            else if(spef_number == 1){
                int i = 0;
                bool cond = false;
                while(cond == false && i < 3){
                    if(inv.getCookwareAt(i) != 0){
                        cout << "Oh no! A nasty looking chef took ur cooking equipment." << endl;
                        inv.setCookwareAt(inv.getCookwareAt(i) - 1,i);
                        cond = true;
                    }
                    else{
                        i++;
                    }
                }
                if (cond == false){
                    cout << "You got lucky. A nasty chef went for ur cooking bag but it's empty." << endl;
                }
            }
            else{
                if (inv.getArmor() != 0){
                    inv.setArmor(inv.getArmor() - 1);
                    cout << "That was close! A phantom just ripped the armor right off your body." << endl;
                }
                else{
                    cout << "A phantom swooped right by your head. That was close!" << endl;
                }
            }
        }
        else if(event_number < 4){
            int spef_number = (rand() % 2);
            if(spef_number == 0){
                if (inv.getArmor() != 0){
                    inv.setArmor(inv.getArmor() - 1);
                    cout << "That was close! A phantom just ripped the armor right off your body. Good thing it wasn't your arm." << endl;
                }
                else{
                    cout << "A phantom swooped right by your head. That was close!" << endl;
                }
            }
            else if(spef_number == 1){
                int i = 0;
                bool cond = false;
                while(cond == false && i < 5){
                    if(inv.getWeaponsAt(i) != 0){
                        cout << " Oh no! A big ugly slime man took one of your weapons as you left the room." << endl;
                        inv.setWeaponsAt(inv.getWeaponsAt(i) - 1,i);
                        cond = true;
                    }
                    else{
                        i++;
                    }
                }
                if (cond == false){
                    cout << "You got lucky. A big slime man went for ur weapons bag but it was empty." << endl;
                }
            }
        }
        else if(event_number < 7){
            bool cond = false;
            while(cond == false){
                int spef_number = (rand() % 4) + 1;
                if(memb[spef_number].isAlive() == true){
                    cond = true;
                    cout << "Oh no! One of your party members got a dungeon stomach parasite." << endl;
                    if(memb[spef_number].getHunger() < 11){
                        memb[spef_number].killMember();
                        cout << memb[spef_number].getName() <<" died from the parasite." << endl;
                    }
                    else{
                        memb[spef_number].decHunger(10);
                        cout << "The party member " << memb[spef_number].getName() << " lost 10 hunger points." << endl;
                    }
                }
            }
        }
        //there is one additional misfortune chance which result in one party member being trapped in the room
        else{
            bool cond = false;
            while(cond == false){
                int spef_number = (rand() % 4) + 1;
                if(memb[spef_number].isAlive() == true){
                    cond = true;
                    cout << "Oh no! Just when you thought it was over the floor started collapsing." << endl;
                    memb[spef_number].killMember();
                    cout << memb[spef_number].getName() <<" did not get to the exit in time." << endl;
                }
            }
        }
        inv.setPartyAt(memb[0], 0);
        inv.setPartyAt(memb[1], 1);
        inv.setPartyAt(memb[2], 2);
        inv.setPartyAt(memb[3], 3);
        inv.setPartyAt(memb[4], 4);
    }
    else{
        //no misfortune
    }
    return inv;
}

//basically rock paper scissors to enter the door without a key
bool doorPuzzle()
{
    int wins = 0;
    int losses = 0;
    cout << "To enter the room without a key, you must win Boulder, Parchment, Shears." << endl;
    while(true){
        srand(time(0));
        //door chooses 1,2, or 3
        int doorChoice = (rand() % 3) + 1;
        string option;
        //user input
        cout << "Choose: boulder(b), parchment(p) or shears(s)" << endl;;
        cin >> option;
        //three ways for the player to win
        if(option == "b" && doorChoice == 1){
            cout << "The door chooses shears." << endl;
            cout << "You win this round!"<< endl;
            wins++;
        }else if(option == "p" && doorChoice == 2){
            cout << "The door chooses boulder."<< endl;
            cout << "You win this round!"<< endl;
            wins++;
        }else if(option == "s" && doorChoice == 3){
            cout << "The door chooses parchment."<< endl;
            cout << "You win this round!"<< endl;
            wins++;
        //anything else counts as a loss
        }else{
            //different messages for how you lost
            if(doorChoice == 1){
                cout << "The door choose shears."<< endl;
                cout << "You lost."<< endl;
                losses++;
            }else if(doorChoice == 2){
                cout << "The door choose boulder."<< endl;
                cout << "You lost."<< endl;
                losses++;
            }else if(doorChoice == 3){
                cout << "The door choose parchment."<< endl;
                cout << "You lost."<< endl;
                losses++;
            }
           
        }
        //wins or losses must equal 3
        if(wins  == 3 || losses == 3){
            break;
        }








    }
    //output if you win
    if(wins == 3){
        cout << "You have defeated the door!" << endl;
        cout << "The door unlocks without needing a key." <<  endl;
        return true;
    }
    //output if you lose
    else if(losses == 3){
        cout << "The door grows tired of defeating your party." << endl;
        return false;
        //kill one member outside of function because it wouldn't update members
    }








}


//battle function for monster interactions
Inventory battle(int level, Inventory inv){
    Member memb[5] {inv.getPartyAt(0),inv.getPartyAt(1),inv.getPartyAt(2),inv.getPartyAt(3),inv.getPartyAt(4)};
    string line;
    vector<string> lines;
    srand(time(0));

    //read from monster text file
    ifstream file("monsters.txt");



    while(getline(file,line)){
        lines.push_back(line);  
    }
    //randomly select monster
    int random_number=rand() % 20;


    string arr[2];

    Merchant merch;
    //splits line into monster and power
    merch.split(lines[random_number], ',', arr, 2);


    int choice;
    cout << "You just ran into a " << arr[0] << " with power level " << level << "." << endl;
    cout << "Think you can beat this beast?" << endl;
    //must have weapons to attack
    if(inv.getWeaponsAt(0) != 0 || inv.getWeaponsAt(1) != 0 || inv.getWeaponsAt(2) != 0 || inv.getWeaponsAt(3) != 0 || inv.getWeaponsAt(4) != 0 ){
        cout << "1. Surrender" << endl;
        cout << "2. Attack" << endl;
        cin >> choice;
    }
    //no weapons you can only surrender
    else{
        cout << "1. Surrender! You have no weapon!" << endl;
        cin >> choice;
    }
        //surrender
        if(choice == 1){
           
            bool cond = false;
            int spef_number = 0;
            while(cond == false)
            {
                //randomly chooses one member to die, and checks to make sure that they are still alive before killing them
                spef_number = (rand() % 4) + 1;
                if(memb[spef_number].isAlive() == true)
                {
                    cond = true;
                    cout << "Oh no! One of your party members got grabbed as you were fleeing." << endl;
                    memb[spef_number].killMember();
                    cout << memb[spef_number].getName() <<" died from the monster." << endl;
                }
            }
        }
        //fight
        else if(choice == 2)
        {
            //calculating all the different double values for the win or loss calculation
            double numWeapons = 0;
            for (int i=0; i < 5; i++)
            {
                numWeapons += inv.getWeaponsAt(i);
            }
            double w = (5 * numWeapons) + (inv.getWeaponsAt(2)) + (inv.getWeaponsAt(3) * 2) + (inv.getWeaponsAt(4) * 3);
            double d = 0;
            for (int i=0; i < 5; i++)
            {
                if(inv.getWeaponsAt(i) != 0)
                {
                    d++;
                }
            }
            if(d == 5){
                d = 4;
            }
            double a = inv.getArmor();
            double c = level;
            double r1 = (rand() % 7) + 1;
            double r2 = (rand() % 7) + 1;



            double outcome = (r1 * w + d) - ((r2-c)/a);
            //winning outcome
            if (outcome > 0)
            {
                inv.incGold(10 * c);
                inv.setIng(inv.getIng()+(5*c));
            }
            //loser outcome
            else
            {
                int perc_gold = inv.getGold() *.25;
                inv.decGold(perc_gold);
                int food_ran = (rand() % 30) + 1;
                if(inv.getIng() > food_ran){
                    inv.setIng(inv.getIng() - food_ran);
                }
                else{
                    inv.setIng(0);
                }
                for (int i=1; i < 5; i++){
                    int rand_die = (rand() % 10);
                    if(rand_die == 0){
                        memb[i].killMember();
                        cout << "Oh no! One of your party members got grabbed as you were fleeing." << endl;
                        cout << memb[i].getName() <<" died from the monster." << endl;
                    }
                }
            }
        }
        else{
            cout << "Invalid input." << endl;
        }

        //after the battle, each member has a 50% chance of hunger minus 1
        int hung1 = rand() % 2;
        if (hung1 == 0)
        {
            cout << memb[0].getName() << " Lost 1 unit of fullness!" << endl;
            memb[0].decHunger(1);
        }
        int hung2 = rand() % 2;
        if (hung2 == 1)
        {
            cout << memb[1].getName() << " Lost 1 unit of fullness!" << endl;
            memb[1].decHunger(1);
        }
        int hung3 = rand() % 2;
        if (hung3 == 0)
        {
            cout << memb[2].getName() << " Lost 1 unit of fullness!" << endl;
            memb[2].decHunger(1);
        }
        int hung4 = rand() % 2;
        if (hung4 == 1)
        {
            cout << memb[3].getName() << " Lost 1 unit of fullness!" << endl;
            memb[3].decHunger(1);
        }
        int hung5 = rand() % 2;
        if (hung5 == 0)
        {
            cout << memb[4].getName() << " Lost 1 unit of fullness!" << endl;
            memb[4].decHunger(1);
        }


        inv.setPartyAt(memb[0], 0);
        inv.setPartyAt(memb[1], 1);
        inv.setPartyAt(memb[2], 2);
        inv.setPartyAt(memb[3], 3);
        inv.setPartyAt(memb[4], 4);


    return inv;
}


//a function which allows the party to select ingredients and cookware, and then gain health based on random chance
Inventory cookAndEat(Inventory inv)
{
    Member memb[5] {inv.getPartyAt(0),inv.getPartyAt(1),inv.getPartyAt(2),inv.getPartyAt(3),inv.getPartyAt(4)};
    srand(time(0));
    cout << "Your party has decided to make camp to recover." << endl;


    //cannot cook without both ing and cookware
    if(inv.getCookwareAt(0)!=0 || inv.getCookwareAt(1)!=0 || inv.getCookwareAt(2)!=0 && inv.getIng() >= 5)
    {
        cout << "You currently have " << inv.getIng() << " kg of ingredients." << endl;
        cout << "Your cookware includes:" << endl;
        cout << " 1. Ceramic Pot x" << inv.getCookwareAt(0) << endl;
        cout << " 2. Frying Pan x" << inv.getCookwareAt(1) << endl;
        cout << " 3. Cauldron x" << inv.getCookwareAt(2) << endl;






        //get user input for number of health wanting to increase
        int ing;
        cout << "How healthy of a meal do you want to cook? (1 health point requires 5 ingredients)" << endl;
        cin >> ing;
        if((ing*5) > inv.getIng())
        {
            ing = inv.getIng()/5;
            cout << "You only have enough for " << ing << " health points." << endl;
        }
        //decrease ing
        inv.setIng(inv.getIng() - ing*5);






        //user input for selecting cookware
        int cook;
        cout << "Now select your cookware: 1, 2, or 3" << endl;
        cin >> cook;
        if (inv.getCookwareAt(cook - 1) == 0)
        {
            cout << "You don't have this item." << endl;
            cout << "You wasted all of your used ingredients" << endl;
        }
        else
        {
            //each choice has its own percent of breaking
            if(cook == 1)
            {
                //25% chance of breaking
                int r = (rand() % 4);
                if(r == 0)
                {
                    //breaks
                    cout << "Oh no your cookware broke while cooking! How unlucky." << endl;
                    inv.setCookwareAt(inv.getCookwareAt(0) - 1, 0);
                }
                else
                {
                    //doesn't break
                    cout << "Congrats you cooked an amazing meal for your party." << endl;
                    for (int i = 0; i < 5; i++){
                        memb[i].incHunger(ing);
                    }
                }
            }
            else if(cook == 2)
            {
                //10% chance of breaking
                int r = (rand() % 10);
                if(r == 0)
                {
                    cout << "Oh no your cookware broke while cooking! How unlucky." << endl;
                    inv.setCookwareAt(inv.getCookwareAt(0) - 1, 0);
                }
                else
                {
                    cout << "Congrats you cooked an amazing meal for your party." << endl;
                    for (int i = 0; i < 5; i++){
                        memb[i].incHunger(ing);
                    }
                }
            }
            else if(cook == 3)
            {
                //2% chance of breaking
                int r = (rand() % 50);
                if(r == 0)
                {
                    cout << "Oh no your cookware broke while cooking! How unlucky." << endl;
                    inv.setCookwareAt(inv.getCookwareAt(0) - 1, 0);
                }
                else
                {
                    cout << "Congrats you cooked an amazing meal for your party." << endl;
                    for (int i = 0; i < 5; i++){
                        memb[i].incHunger(ing);
                    }
                }
            }






            //outputs the changed health of the party members
            cout << "Now you have " << inv.getIng() << " kg of ingredients." << endl;
            cout << "Your party members fullnesses are: " << endl;
            cout << memb[0].getName() << ": " << memb[0].getHunger() << endl;
            cout << memb[1].getName() << ": " << memb[1].getHunger() << endl;
            cout << memb[2].getName() << ": " << memb[2].getHunger() << endl;
            cout << memb[3].getName() << ": " << memb[3].getHunger() << endl;
            cout << memb[4].getName() << ": " << memb[4].getHunger() << endl;




            inv.setPartyAt(memb[0], 0);
            inv.setPartyAt(memb[1], 1);
            inv.setPartyAt(memb[2], 2);
            inv.setPartyAt(memb[3], 3);
            inv.setPartyAt(memb[4], 4);
        }
    }
       
    return inv;
}


//checks hunger levels for all party members, displaying if they have or are close to starving
Inventory checkHunger(Inventory inv){
    //for loop for all members
    for (int i=0; i < 5; i++)
    {
        //low hunger condition
        if(inv.getPartyAt(i).getHunger() <= 5){
            if(inv.getPartyAt(i).getHunger() == 0){
                //dead from starvation message
                cout << "Party member " << inv.getPartyAt(i).getName() << " starved to death." << endl;
                Member memb = inv.getPartyAt(i);
                memb.killMember();
                inv.setPartyAt(memb,i);
            }
            else{
                //close to starving warning
                cout << "Warning: " << inv.getPartyAt(i).getName() << "is on the brink of starvation!" << endl;
                cout << "You should cook food for your party!" << endl;
            }
        }
    }
    return inv;  
}


//function which prints game data to game results text file, parameters cover all data
void phase3file(Inventory inv, Status stat, Map mp, int num_monsters, int num_turns){
    //opening file
    ofstream output_file("game_results.txt");






    //adding info to output file
    output_file << "Party leader: " << inv.getPartyAt(0).getName() <<"-with remaining members:";
    for (int i = 1; i < 5; i++){
        if(inv.getPartyAt(i).isAlive()){
            output_file << inv.getPartyAt(i).getName() << "  ";
        }
    }
    cout << endl << endl;




    //adding all info to output file
    output_file << "Number of rooms cleared: "<< stat.getRooms_cleared() << endl << endl;
    output_file << "Gold pieces remaining: " << inv.getGold() << endl << endl;
    output_file << "Treasures remaining: " << inv.gettreasure_nameeAt(0) << " - " << inv.getTreasuresAt(0) << "  " << inv.gettreasure_nameeAt(1) << " - " << inv.getTreasuresAt(1) << "  " << inv.gettreasure_nameeAt(2) << " - " << inv.getTreasuresAt(2) << "  " << inv.gettreasure_nameeAt(3) << " - " << inv.getTreasuresAt(3) << "  " << inv.gettreasure_nameeAt(4) << " - " << inv.getTreasuresAt(4) <<endl << endl;
    output_file << "Spaces explored: " << mp.getNum_explored() << endl << endl;
    output_file << "Monsters defeated: " << num_monsters << endl << endl;
    output_file << "Turns elapsed: " << num_turns << endl << endl;
}


//this function prints all the info that was saved to the game results text file
void phase3print(string filename)
{
    //reading from file
    ifstream input_file;




    input_file.open(filename);




    string line = "";
    while(getline(input_file, line))
    {
        //each line has an empty linw space inbetween
        cout << line;
        cout << endl << endl;
    }
    input_file.close();
}

// the second part of the game
void phase2(Map map, Status stat, Inventory inv, Merchant merch)
{
    int num_turns = 0;
    int num_monsters = 0;
    int opt = 1;
    cout << endl;
    while(opt == 1 || opt == 2 || opt == 3 || opt == 4 || opt == 5)
    {
        // pinting of menue
        stat.displayStatus(inv);
        cout << endl << "MAP:" << endl << endl;
        map.displayMap();
        cout << "  Select one:" << endl;
        cout << "  1. Move" << endl;
        cout << "  2. Investigate" << endl;
        cout << "  3. Pick a Fight" << endl;
        cout << "  4. Cook and Eat" << endl;
        cout << "  5. Give up" << endl;
        cin >> opt;

        // making sure the user pusts the right input
        while ((opt > 5) || (0 >= opt))
        {
            cout << endl;
            map.displayMap();
            cout << "Invalid input." << endl;
            stat.displayStatus(inv);
            map.displayMap();
            cout << "  Select one:" << endl;
            cout << "  1. Move" << endl;
            cout << "  2. Investigate" << endl;
            cout << "  3. Pick a Fight" << endl;
            cout << "  4. Cook and Eat" << endl;
            cout << "  5. Give up" << endl << endl;
            cin >> opt;
        }
        if (opt == 1)
        {
            // menue for direction of movements
            char mo;
            cout << " Choose a direction: (w-up, a-left, s-down, d-right)" << endl;
            cin >> mo;

            // making sure user input is valid
            while ((mo != 'w') && (mo != 'a') && (mo != 's') && (mo != 'd'))
            {
                cout << "Invalid input. Try lower case." << endl;
                cout << " Choose a direction: (w-up, a-left, s-down, d-right)" << endl;
                cin >> mo;
            }
            
            
            // making sure the movement chosen is on the map
            while (!map.move(mo))
            {
                cout << "Opps! out of map! Try another direction." << endl;
                cin >> mo;
            }

            
            // Moving to an unexplored space makes the sorcerer angry
            // shecking every direction and increasing the anger if the move that direction
            // and increasing the anger by one
            if (mo == 'w')
            {
                if (!map.isExplored(map.getPlayerRow()-1,map.getPlayerCol()))
                {
                    stat.setAnger(stat.getAnger()+1);
                }
            }
            if (mo == 's')
            {
                if (!map.isExplored(map.getPlayerRow()+1,map.getPlayerCol()))
                {
                    stat.setAnger(stat.getAnger()+1);
                }
            }
            if (mo == 'a')
            {
                if (!map.isExplored(map.getPlayerRow(),map.getPlayerCol()-1))
                {
                    stat.setAnger(stat.getAnger()+1);
                }
            }
            if (mo == 'd')
            {
                if (!map.isExplored(map.getPlayerRow(),map.getPlayerCol()+1))
                {
                    stat.setAnger(stat.getAnger()+1);
                }
            }

            srand(time(0));
            // getting random nums for each team member 
            // it's a 1 in 5 chnace to decrease their hunger
            // making sure to change the inventory

            int hung1 = rand() % 5;
            if (inv.getPartyAt(0).isAlive())
            {
                if (hung1 == 1)
                {
                    cout << inv.getPartyAt(0).getName() << " Lost 1 unit of fullness!" << endl;
                    Member memb = inv.getPartyAt(0);
                    memb.decHunger(1);
                    inv.setPartyAt(memb ,0);
                }
            }
            if (inv.getPartyAt(0).isAlive())
            {
                int hung2 = rand() % 5;
                if (hung2 == 2)
                {
                    cout << inv.getPartyAt(1).getName() << " Lost 1 unit of fullness!" << endl;
                    Member memb = inv.getPartyAt(1);
                    memb.decHunger(1);
                    inv.setPartyAt(memb ,1);
                }

            }
            if (inv.getPartyAt(0).isAlive())
            {
                int hung3 = rand() % 5;
                if (hung3 == 3)
                {
                    cout << inv.getPartyAt(2).getName() << " Lost 1 unit of fullness!" << endl;
                    Member memb = inv.getPartyAt(2);
                    memb.decHunger(1);
                    inv.setPartyAt(memb ,2);
                }

            }
            if (inv.getPartyAt(0).isAlive())
            {
                int hung4 = rand() % 5;
                if (hung4 == 4)
                {
                    cout << inv.getPartyAt(3).getName() << " Lost 1 unit of fullness!" << endl;
                    Member memb = inv.getPartyAt(3);
                    memb.decHunger(1);
                    inv.setPartyAt(memb, 3);
                }
            }
            if (inv.getPartyAt(0).isAlive())
            {
                int hung5 = rand() % 5;
                if (hung5 == 0)
                {
                    cout << inv.getPartyAt(4).getName() << " Lost 1 unit of fullness!" << endl;
                    Member memb = inv.getPartyAt(4);
                    memb.decHunger(1);
                    inv.setPartyAt(memb, 4);
                }
            }
            
            
            
            
            

            
            
            // if room location then say they found a room
            // - if they have a key the use it and make them battle
            // - if they lost then call misfortune
            // - if they won then inrease the merchant prices, inrease rooms cleared, and call room misfortune
            // - if they surrendered then call the ending of the game 
            // if they dont have any keys then askthem if they want to enter the room with the door puzzle
            // - if they say yes then make them solve the puzzle
            // - if they solve the riddle then they battle
            // - if they loose  then one of the memebers die and cant get in the room  
            if (map.isRoomLocation(map.getPlayerRow(), map.getPlayerCol()))
            {
                cout << "You have found a room." << endl;
                if (stat.getKeys()>=1)
                {
                    stat.useKeys();
                    cout << "Used one of your keys." << endl;
                    int gold_b = inv.getGold();
                    inv = battle(stat.getRooms_cleared()+2,inv);
                    if (gold_b > inv.getGold())
                    {
                        // lost
                        cout << "You were defeeated! Your Party left the room." << endl;
                        inv = misfortune(inv);
                    }
                    else if (gold_b < inv.getGold())
                    {
                        // won
                        merch.increasePrices();
                        cout << "You won!" << endl;
                        cout << "The room is cleared!" << endl;
                        inv = room_misfortune(inv);
                        stat.gainRooms_cleared();
                        map.removeRoom(map.getPlayerRow(), map.getPlayerCol());
                        map.exploreSpace(map.getNumRows(), map.getPlayerCol());
                        num_monsters++;
                    }
                    else
                    {
                        cout << "You surrendered, do regret it?" << endl;
                        phase3file(inv, stat, map, num_monsters, num_turns);
                        phase3print("game_results.txt");
                        break;
                    }
                }
                else
                {
                    char y_n;
                    cout << "No key! Do want to open the door? (y/n)" << endl;
                    cin >> y_n;
                    if (y_n == 'y')
                    {
                       if(doorPuzzle())
                       {
                            cout << "You entered the room!" << endl;
                            int gold_b = inv.getGold();
                            inv = battle(stat.getRooms_cleared()+2,inv);
                            if (gold_b < inv.getGold())
                            {
                                // lost
                                cout << "You were defeeated! Your Party left the room." << endl;
                                inv = misfortune(inv);
                            }
                            else if (gold_b > inv.getGold())
                            {
                                // won
                                cout << "You won!" << endl;
                                merch.increasePrices();
                                cout << "The room is cleared!" << endl;
                                inv = room_misfortune(inv);
                                stat.gainRooms_cleared();
                                map.removeRoom(map.getPlayerRow(), map.getPlayerCol());
                                map.exploreSpace(map.getPlayerRow(),map.getPlayerCol());
                                num_monsters++;
                            }
                            else
                            {
                                cout << "You surrendered, do regret it?" << endl;
                                cout << "**********" << endl;
                                cout << "| ending |" << endl << endl;
                                phase3file(inv, stat, map, num_monsters, num_turns);
                                phase3print("game_results.txt");
                                break;
                            }
                       }
                       else
                       {
                            bool cond = false;
                            int spef_number = 0;
                            while(cond == false)
                            {
                                spef_number = (rand() % 4) + 1;
                                if(inv.getPartyAt(spef_number).isAlive() == true)
                                {
                                    cond = true;
                                    cout << "Oh no! One of your party members got grabbed as you were fleeing." << endl;
                                    Member memb = inv.getPartyAt(spef_number);
                                    memb.killMember();
                                    inv.setPartyAt(memb, spef_number);
                                    cout << inv.getPartyAt(spef_number).getName() <<" died from the door trap." << endl;
                                }
                            }    
                        }
                    }

                }
            }
            
            // if the x is at one of the npc locations then print that you found the npc
            // prompt the riddle if they solve the riddle then they can shop
            // if they don't then they fight the npc and the npc becomes explored and they can't come back
            if (map.isNPCLocation(map.getPlayerRow(), map.getPlayerCol()))
            {
                cout << "NPC here!" << endl;
                if (merch.solveRiddle())
                {
                    inv = merch.shopM(inv);
                }
                else
                {
                    cout << "You failed my test dummy! Now die!" << endl;
                    int gold_b = inv.getGold();
                    inv = battle(stat.getRooms_cleared()+1, inv);
                    if (gold_b > inv.getGold())
                    {
                        // won
                        cout << "You won!" << endl;
                        num_monsters++;
                       
                    }
                }
                map.removeNPC(map.getPlayerRow(), map.getPlayerCol());
                map.exploreSpace(map.getPlayerRow(), map.getPlayerCol());
            }


            // if they arrive at he dundeon exit
            if (map.isDungeonExit(map.getPlayerRow(), map.getPlayerCol()))
            {
                // checking if they have all rooms cleared
                if (stat.getRooms_cleared() < 5)
                {
                    // letting the player they can come back
                    cout << "You have not defeated all the monster rooms. Come back after." << endl;
                }
                else
                {
                    // they battle the final boss 
                    cout << "You are about to face the sorcerer's final monster!" << endl;
                    int gold_b = inv.getGold();
                    inv = battle(stat.getRooms_cleared()+2, inv);
                    // checking if they won
                    if (gold_b > inv.getGold())
                    {
                        // won
                        cout << "You won!" << endl;
                        num_monsters++;
                    }
                    // ending of game
                    cout << "**********" << endl;
                    cout << "| ending |" << endl << endl;
                    phase3file(inv, stat, map, num_monsters, num_turns);
                    phase3print("game_results.txt");
                    break;
                }
            }

        }

        if (opt == 2)
        {
            // checking that the spot is not explored
            if (!map.isExplored(map.getPlayerRow(), map.getPlayerCol()))
            {
                srand(time(0));
                // random chance one of the teammates decreasing hunger
                int hung1 = rand() % 2;
                
                if (hung1 == 0)
                {
                    cout << inv.getPartyAt(0).getName() << " Lost 1 unit of fullness!" << endl;
                    Member memb = inv.getPartyAt(0);
                    memb.decHunger(1);
                    inv.setPartyAt(memb ,0);
                }
                int hung2 = rand() % 2;
                if (hung2 == 1)
                {
                    cout << inv.getPartyAt(1).getName() << " Lost 1 unit of fullness!" << endl;
                    Member memb = inv.getPartyAt(1);
                    memb.decHunger(1);
                    inv.setPartyAt(memb ,1);
                }
                int hung3 = rand() % 2;
                if (hung3 == 0)
                {
                    cout << inv.getPartyAt(2).getName() << " Lost 1 unit of fullness!" << endl;
                    Member memb = inv.getPartyAt(2);
                    memb.decHunger(1);
                    inv.setPartyAt(memb, 2);
                }
                int hung4 = rand() % 2;
                if (hung4 == 1)
                {
                    cout << inv.getPartyAt(3).getName() << " Lost 1 unit of fullness!" << endl;
                    Member memb = inv.getPartyAt(3);
                    memb.decHunger(1);
                    inv.setPartyAt(memb, 3);
                }
                int hung5 = rand() % 2;
                if (hung5 == 0)
                {
                    cout << inv.getPartyAt(4).getName() << " Lost 1 unit of fullness!" << endl;
                    Member memb = inv.getPartyAt(4);
                    memb.decHunger(1);
                    inv.setPartyAt(memb, 4);
                }
                // 10% chance they find a key when they explore
                int chance = rand() % 10;
                if (chance == 5)
                {
                    cout << "You have found a key!" << endl;
                    stat.gainKeys();
                }
                // 20% chance they find treasure
                if (chance == 3 || chance == 4)
                {
                    if (stat.getRooms_cleared() == 0)
                    {
                        inv.setTreasuresAt(inv.getTreasuresAt(0)+1, 0);
                        cout << "You found a " << inv.gettreasure_nameeAt(0) << " worth " << merch.getTreasurePAt(0) << " Gold."<< endl;
                    }
                    if (stat.getRooms_cleared() == 1)
                    {
                        inv.setTreasuresAt(inv.getTreasuresAt(0)+1, 0);
                        cout << "You found a " << inv.gettreasure_nameeAt(0) << " worth " << merch.getTreasurePAt(0) << " Gold."<< endl;
                    }
                    if (stat.getRooms_cleared() == 2)
                    {
                        inv.setTreasuresAt(inv.getTreasuresAt(1)+1, 1);
                        cout << "You found a " << inv.gettreasure_nameeAt(1) << " worth " << merch.getTreasurePAt(1) << " Gold."<< endl;
                    }
                    if (stat.getRooms_cleared() == 3)
                    {
                        inv.setTreasuresAt(inv.getTreasuresAt(2)+1, 2);
                        cout << "You found a " << inv.gettreasure_nameeAt(2) << " worth " << merch.getTreasurePAt(2) << " Gold."<< endl;
                    }
                    if (stat.getRooms_cleared() == 4)
                    {
                        inv.setTreasuresAt(inv.getTreasuresAt(3)+1, 3);
                        cout << "You found a " << inv.gettreasure_nameeAt(3) << " worth " << merch.getTreasurePAt(3) << " Gold."<< endl;
                    }
                    if (stat.getRooms_cleared() == 5)
                    {
                        inv.setTreasuresAt(inv.getTreasuresAt(4)+1, 4);
                        cout << "You found a " << inv.gettreasure_nameeAt(4) << " worth " << merch.getTreasurePAt(4) << " Gold."<< endl;
                    }  
                }
                // 20% chance they will find a monster
                if (chance == 2 || chance == 1)
                {
                    int gold_b = inv.getGold();
                    inv = battle(stat.getRooms_cleared()+1, inv);
                    if (gold_b > inv.getGold())
                    {
                        // won
                        cout << "You won!" << endl;
                        num_monsters++;
                    }
                }
                // apply misfortune 
                inv = misfortune(inv);
                // explore the space 
                map.exploreSpace(map.getPlayerRow(), map.getPlayerCol());
            }
            else
            {
                // if the spot id explored then you tell them
                cout << "You already investigated this area! move and try another spot." << endl;
            }
        }

        if (opt == 3)
        {
            // call the battle function
            cout << "Here comes the monster!" << endl;

            int gold_b = inv.getGold();
            inv = battle(stat.getRooms_cleared()+1, inv);
            // if they win then add to monsters killed
            if (gold_b > inv.getGold())
            {
                // won
                num_monsters++;
            }
            inv = misfortune(inv);

            srand(time(0));

            // random chance one of the teammates decreasing hunger
            int hung1 = rand() % 2;
            if (hung1 == 0)
            {
                cout << inv.getPartyAt(0).getName() << " Lost 1 unit of fullness!" << endl;
                Member memb = inv.getPartyAt(0);
                memb.decHunger(1);
                inv.setPartyAt(memb ,0);
            }
            int hung2 = rand() % 2;
            if (hung2 == 1)
            {
                cout << inv.getPartyAt(1).getName() << " Lost 1 unit of fullness!" << endl;
                Member memb = inv.getPartyAt(1);
                memb.decHunger(1);
                inv.setPartyAt(memb ,1);
            }
            int hung3 = rand() % 2;
            if (hung3 == 0)
            {
                cout << inv.getPartyAt(2).getName() << " Lost 1 unit of fullness!" << endl;
                Member memb = inv.getPartyAt(2);
                memb.decHunger(1);
                inv.setPartyAt(memb, 2);
            }
            int hung4 = rand() % 2;
            if (hung4 == 1)
            {
                cout << inv.getPartyAt(3).getName() << " Lost 1 unit of fullness!" << endl;
                Member memb = inv.getPartyAt(3);
                memb.decHunger(1);
                inv.setPartyAt(memb, 3);
            }
            int hung5 = rand() % 2;
            if (hung5 == 0)
            {
                cout << inv.getPartyAt(4).getName() << " Lost 1 unit of fullness!" << endl;
                Member memb = inv.getPartyAt(4);
                memb.decHunger(1);
                inv.setPartyAt(memb, 4);
            }

            
        }

        if (opt == 4)
        {
            // call the cook and eat function
            inv = cookAndEat(inv);
            // chance of misfortune
            inv = misfortune(inv);
        }

        if (opt == 5)
        {
            // making they want to give up
            char yn;
            cout << "Are you sure you want to end the game and give up? (y/n)" << endl << endl;
            cin >> yn;
            // end the game if they chhose to otherwise they go back to the menue
            if (yn =='y')
            {
                cout << "**********" << endl;
                cout << "| ending |" << endl << endl;
                phase3file(inv, stat, map, num_monsters, num_turns);
                phase3print("game_results.txt");
                break;
            }
            else
            {
                continue;
            }
        }

        // check the hunger
        inv = checkHunger(inv);
        
        // checking for one of the cases for ending
        // if the anger gets to 100
        if (stat.getAnger() == 100)
        {
            cout << "**********" << endl;
            cout << "| ending |" << endl;
            cout << endl << "You have angered the sorcerer!" << endl;
            phase3file(inv, stat, map, num_monsters, num_turns);
            phase3print("game_results.txt");
            break;
        }
        // checking for one of the cases for ending
        // if all teamates die
        if (!inv.getPartyAt(1).isAlive()&&!inv.getPartyAt(2).isAlive()&&!inv.getPartyAt(3).isAlive()&&!inv.getPartyAt(4).isAlive())
        {
            cout << "**********" << endl;
            cout << "| ending |" << endl;
            cout << endl << "All of your teammates died!" << endl;
            phase3file(inv, stat, map, num_monsters, num_turns);
            phase3print("game_results.txt");
            break;
        }
        // checking for one of the cases for ending
        // if the leader dies
        if ((inv.getPartyAt(0).getHunger() == 0) || (!inv.getPartyAt(0).isAlive()))
        {
            cout << "**********" << endl;
            cout << "| ending |" << endl;
            cout << endl << "The leader has died!" << endl;
            phase3file(inv, stat, map, num_monsters, num_turns);
            phase3print("game_results.txt");
            break;
        }
        // applying the sorting algarithem
        inv = sortTeammatesHunger(inv);
        // making sure they read everything
        char yn;
        cout << endl <<"Check what happened above. Continue journey? (y/n)" << endl;
        cin >> yn;

        if (yn == 'y')
        {
            continue;
        }
        else
        {
            continue;
        }
        // incrementing turns
        num_turns++;
        
        
        
    }
}

int main()
{
    srand(time(0));
    // all the default constructors
    Map map;
    Status stat;
    Inventory inv;
    Merchant merchant;

    cout<< endl << endl;
    cout << "                                         ******************" << endl;
    cout << "                                         | Dungeon Escape |" << endl;
    cout << "                                         ******************" << endl;
    cout << endl;


    // ------------------------------
    //  ---- Map Generation -----
    int ran_row1 = 0;
    int ran_col1 = 0;
    bool cond = false;
    // adding  the player spot
    while (cond == false)
    {
        ran_row1 = (rand() % 12);
        ran_col1 = (rand() % 12);
        if (map.isFreeSpace(ran_row1, ran_col1))
        {
            map.setPlayerPosition(ran_row1,ran_col1);
            cond = true;
        }
    }
    // adding the dungeon exit
    cond = false;
    while (cond == false){
        ran_row1 = (rand() % 12);
        ran_col1 = (rand() % 12);
        if (map.isFreeSpace(ran_row1, ran_col1))
        {
            map.setDungeonExit(ran_row1,ran_col1);
            cond = true;
        }
    }
    // adding all five npcs
    for (int i = 0; i < 5; i++)
    {
        while (cond == false){
            ran_row1 = (rand() % 12);
            ran_col1 = (rand() % 12);
            if (map.isFreeSpace(ran_row1, ran_col1))
            {
                map.addNPC(ran_row1,ran_col1);
                cond = true;
            }
        }
        cond = false;
    }
    // adding all five rooms
    for (int i = 0; i < 5; i++)
    {
        while (cond == false){
            ran_row1 = (rand() % 12);
            ran_col1 = (rand() % 12);
            if (map.isFreeSpace(ran_row1, ran_col1))
            {
                map.addRoom(ran_row1,ran_col1);
                cond = true;
            }
        }
        cond = false;
    }

// ===================================


    // asking for member names and making the member object members
    string name1 = "";
    string name2 = "";
    string name3 = "";
    string name4 = "";
    string name5 = "";
    
    cout << "What is your name?" << endl;
    getline(cin, name1);
    Member N1(name1);
    inv.setPartyAt(N1,0); 
    cout << "What are your teamates' names?" << endl;
    cout << "Player 2:" << endl;
    getline(cin, name2);
    cout << "Player 3:" << endl;
    getline(cin, name3);
    cout << "Player 4:" << endl;
    getline(cin, name4);
    cout << "Player 5:" << endl;
    getline(cin, name5);
    Member N2(name2);
    inv.setPartyAt(N2,1); 
    Member N3(name3);
    inv.setPartyAt(N3,2); 
    Member N4(name4);
    inv.setPartyAt(N4,3); 
    Member N5(name5);
    inv.setPartyAt(N5,4);  


    cout << "                                          ************" << endl;
    cout << "                                          | Merchant |"<< endl;
    cout << endl;
    cout << "Between the 5 of you, you have 100 gold pieces. " << endl;
    cout << "You will need to spend the some of your money on the following items:" << endl;
    cout << endl;
    cout << "- INGREDIENTS. To make food, you have to cook raw ingredients." << endl;
    cout << "- COOKWARE. If you want to cook, you have to have cookware first." << endl;
    cout << "- WEAPONS. You'll want at least one weapon per party member to fend off monsters." << endl;
    cout << "- ARMOR. Armor increases the chances of surviving a monster attack." << endl;
    cout << endl;
    cout << "You can spend all of your money here before you start your journey, " << endl;
    cout << "or you can save some to spend on merchants along the way. But beware, " << endl;
    cout << "some of the merchants in this dungeon are shady characters, and they " << endl;
    cout << "won't always give you a fair price..." << endl;

    // phase 1
    inv = merchant.shopM(inv);
    //phase 2
    phase2(map, stat, inv, merchant);

}