//CSCI1300 Spring 2023 
//Author: Jonah Yunes and Wilder Lockwood
//Recitation: 202 TA: Lin Shi 
//Project 3 - Member.h

#include <iostream>
using namespace std;
#include "Member.h"






//unparamterized constructor for each member
Member::Member()
{
    name = "";
    hunger = 50;
    alive = true;
}


//parameterized constructor for each member
Member::Member(string new_name){
    name = new_name;
    hunger = 50;
    alive = true;
}






//returns name of member
string Member::getName(){
    return name;
}






//returns hunger of each member
int Member::getHunger()
{
 return hunger;
}






//decreases hunger by num
void Member::decHunger(int num){
    hunger -= num;
}






//increases hunger by num
void Member::incHunger(int num){
    hunger += num;
}






//returns whether the member is alive or not
bool Member::isAlive(){
    return alive;
}


//sets alive boolean to false for true
void Member::killMember(){
    alive = false;
}






//member display depends on whether the member is alive or dead, each members display is printed after the inventory
void Member::displayMember(){
    if(alive == true){
        cout << "| " << name << " | Fullness:" << hunger << endl;
    }
    else{
        cout << "| " << name << " | Deceased" << endl;
    }
}




